import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-door-to-door',
  templateUrl: './door-to-door.component.html',
  styleUrls: ['./door-to-door.component.css']
})
export class DoorToDoorComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
